More singly linked list
