#ifndef SUM_X_Y
#define SUM_X_Y

#define SUM(X, Y) ((X) + (Y))
#endif
