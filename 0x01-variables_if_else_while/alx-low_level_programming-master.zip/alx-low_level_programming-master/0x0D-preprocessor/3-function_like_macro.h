#ifndef _FUNCTION_LIKE_MACRO_
#define _FUNCTION_LIKE_MACRO_

#define ABS(X) ((X < (0)) ? ((X) * (-1)) : (X))
#endif
