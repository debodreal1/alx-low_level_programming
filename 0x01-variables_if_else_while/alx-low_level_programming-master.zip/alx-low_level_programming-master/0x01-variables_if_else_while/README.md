variables and if else
