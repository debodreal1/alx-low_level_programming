pointers, arrays, strings
