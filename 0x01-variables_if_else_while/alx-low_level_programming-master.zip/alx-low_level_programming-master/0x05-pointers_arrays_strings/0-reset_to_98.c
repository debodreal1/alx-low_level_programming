#include <stdio.h>
#include "main.h"

/**
 * reset_to_98 - update pointer value to 98
 * @n: parameter to be provided
 * Return: Always 0 (Success)
 */

void reset_to_98(int *n)
{
	*n = 98;
}
