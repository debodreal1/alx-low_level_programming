My C programming begins today
