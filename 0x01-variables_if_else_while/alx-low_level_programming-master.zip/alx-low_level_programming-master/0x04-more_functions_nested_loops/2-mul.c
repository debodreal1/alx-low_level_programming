#include "main.h"

/**
 * mul - multiplies 2 nums
 * @a: first param
 * @b: second param
 * Return: something
 */

int mul(int a, int b)
{
	return (a * b);
}
