More nested loop and functions
