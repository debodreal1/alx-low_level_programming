bit manipulation
