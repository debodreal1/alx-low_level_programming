#include "main.h"

/**
 * add - Entry point for the addition
 * @a: one value to be added together
 * @b: second value to be added
 * Return: Always 0 (Success)
 */

int add(int a, int b)

{
	return (a + b);
}
