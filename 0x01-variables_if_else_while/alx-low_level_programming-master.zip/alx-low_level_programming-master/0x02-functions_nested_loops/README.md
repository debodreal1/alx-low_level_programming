My Nested Loop and Functions
