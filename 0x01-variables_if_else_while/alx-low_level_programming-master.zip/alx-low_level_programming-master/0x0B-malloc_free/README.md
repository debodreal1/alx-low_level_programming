Memory Allocation
