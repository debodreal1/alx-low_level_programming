Structure and type def
