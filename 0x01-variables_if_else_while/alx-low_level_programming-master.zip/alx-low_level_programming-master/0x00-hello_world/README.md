This is my first C exercise
