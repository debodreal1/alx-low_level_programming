more pointers, arrays and strings
