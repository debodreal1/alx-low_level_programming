more malloc task
