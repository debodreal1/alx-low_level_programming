who de check
