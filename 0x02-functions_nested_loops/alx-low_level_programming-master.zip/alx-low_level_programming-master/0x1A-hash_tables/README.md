0x1A. C - Hash tables
