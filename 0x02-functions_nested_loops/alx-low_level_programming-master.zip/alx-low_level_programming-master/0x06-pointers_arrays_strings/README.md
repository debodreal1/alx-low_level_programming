Readme for this Projects.
Pointers array and strings.
Various task completed
