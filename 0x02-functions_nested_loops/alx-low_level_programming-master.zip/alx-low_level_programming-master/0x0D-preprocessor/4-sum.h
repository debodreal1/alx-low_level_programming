#ifndef _SUM_H_
#define _SUM_H_

#define SUM(x, y) ((x) + (y))

#endif
