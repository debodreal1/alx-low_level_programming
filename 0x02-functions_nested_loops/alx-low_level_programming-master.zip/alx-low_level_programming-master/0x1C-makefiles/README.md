0x1C-makefiles
Github Repo - Alx low level
Author - Bright Daniel
