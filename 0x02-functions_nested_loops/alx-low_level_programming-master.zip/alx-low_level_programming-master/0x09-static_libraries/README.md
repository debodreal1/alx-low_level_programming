Static Libaries
