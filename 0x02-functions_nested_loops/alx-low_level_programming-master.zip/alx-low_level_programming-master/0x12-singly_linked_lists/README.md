0x12. C - Singly linked lists
