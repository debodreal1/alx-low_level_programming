0. _putchar
mandatory
Write a program that prints _putchar, followed by a new line.

The program should return 0

1. I sometimes suffer from insomnia. And when I can't fall asleep, I play what I call the alphabet game
mandatory
Write a function that prints the alphabet, in lowercase, followed by a new line.

Prototype: void print_alphabet(void);
You can only use _putchar twice in your code

2. 10 x alphabet
mandatory
Write a function that prints 10 times the alphabet, in lowercase, followed by a new line.

Prototype: void print_alphabet_x10(void);
You can only use _putchar twice in your code

3. islower
mandatory
Write a function that checks for lowercase character.

Prototype: int _islower(int c);
Returns 1 if c is lowercase
Returns 0 otherwise
FYI: The standard library provides a similar function: islower. Run man islower to learn more.

4. isalpha
mandatory
Write a function that checks for alphabetic character.

Prototype: int _isalpha(int c);
Returns 1 if c is a letter, lowercase or uppercase
Returns 0 otherwise
FYI: The standard library provides a similar function: isalpha. Run man isalpha to learn more.

5. Sign

5-sign.c: C function that prints the sign of a number. Returns:
1 and prints + if the number is greater than zero.
0 and prints 0 if the number is zero.
-1 and prints - if the number is less than zero.
6. There is no such thing as absolute value in this world. You can only estimate what a thing is worth to you

6-abs.c: C function that returns the absolute value of an integer.
7. There are only 3 colors, 10 digits, and 7 notes; it's what we do with them that's important

7-print_last_digit.c: C function that prints the last digit of a number. Returns the value of the last digit.
8. I'm federal agent Jack Bauer, and today is the longest day of my life

8-24_hours.c: C function that prints every minute of the day of Jack Bauer, starting from 00:00 to 23:59.
9. Learn your times table

9-times_table.c: C function that prints the 9 times table, starting with 0.
10. a + b

10-add.c: C function that returns the addition of two integers.
11. Holberton School, 98 Battery Street, San Francisco CA 94111

11-print_to_98.c: C function that prints all natural numbers from an input to 98 followed by a new line, as follows:
Numbers are separated by a comma followed by a space.
Numbers are printed in order.
Input represents the number to begin counting from.
98 is the last number printed.
12. The World looks like a multiplication-table, or a mathematical equation, which, turn it how you will, balances itself

100-times_table.c: C function that prints the times table of an input value, starting with 0:
If input is greater than 15 or less than 0, function prints nothing.
13. Nature made the natural numbers; All else is the work of women

101-natural.c: C program that computes and prints the sum of all multiples of 3 or 5 below 1024 (excluded).
14. In computer class, the first assignment was to write a program to print the first 100 Fibonacci numbers. Instead, I wrote a program that would steal passwords of students. My teacher gave me an A

102-fibonacci.c: C program that prints the first 50 Fibonacci numbers, starting with 1 and 2, followed by a new line. Numbers are separated by a comma followed by a space.
15. Even Liber Abbaci

103-fibonacci.c: C program that prints the sum of even-valued Fibonacci numbers not exceeding 4,000,000, followed by a new line.
16. In computer class, the first assignment was to write a program to print the first 100 Fibonacci numbers. Instead, I wrote a program that would steal passwords of students. My teacher gave me an A+

104-fibonacci.c: C program that prints the first 98 Fibonacci numbers, starting with 1 and 2, followed by a new line, without using long long, malloc, pointers, arrays, structures, or any library besides the standard. Numbers are separated by a comma followed by a space.
