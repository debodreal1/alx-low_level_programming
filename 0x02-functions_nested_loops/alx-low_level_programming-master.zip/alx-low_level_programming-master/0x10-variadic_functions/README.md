# Variaidc function project README file

Task 0: A function that returns the sum of all its parameters.

Task 1: A function that prints numbers, followed by a new line.

Task 2: A function that prints strings, followed by a new line.

Task 3: A function that prints anything.
