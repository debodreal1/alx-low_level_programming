0x07. C - Even more pointers, arrays and strings
Tasks
0. memset
	Write a function that fills memory with a constant byte.
1. memcpy
	Write a function that copies memory area.
2. strchr
	Write a function that locates a character in a string.
3. strspn
	Write a function that gets the length of a prefix substring.
4. strpbrk
	Write a function that searches a string for any of a set of bytes.
5. strstr
	Write a function that locates a substring.
6. Chess is mental torture
	Write a function that prints the chessboard.
7. The line of life is a ragged diagonal between duty and desire
	Write a function that prints the sum of the two diagonals of a square matrix of integers.
8. Double pointer, double fun
	Write a function that sets the value of a pointer to a char.
9. My primary goal of hacking was the intellectual curiosity, the seduction of adventure
	Create a file that contains the password for the crackme2 executable.
