All the task of recursion.
Still on the issue of doing hard things
Following alx framework
By Bwave / Bright Oghor
